=== TR Closer ===
Requires Java
License: Oracle

Uses: Jsoup http://jsoup.org/ 1.7.3
Licence: http://jsoup.org/license


TR Closer closes any application(usually your torrent application) if your public IPv4 address matches the one you select. 
The program also supports wildcards, e.g putting 192.167.50.0 will block all 255 addresses. 


A few notes about the sections above:

*   It is normal to see the text: "ERROR: The process "trans*" not found." This simply means that your executable isn't running.
*   0.0.0.0 will close the selected program based on any ip address.
*   The program will detect if your internet connection is offline and will continue to work when your internet connection resumes.


== Installation ==

Run the executable, create a shortcut if you wish and place it in your startup folder.
For windows 7 and below: search for the startup folder and place the shortcut there.
For Windows 8: Press win+r and type shell:startup and place the shortcut there.


== Changelog ==

= 1.0 =
*Initial Release

demthruz.wordpress.com

